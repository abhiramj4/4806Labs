package ThanosCorp.Lab4AbhiramSanthosh;

import org.springframework.data.jpa.repository.JpaRepository;

interface BuddyRepository extends JpaRepository<BuddyInfo, Long> {

}