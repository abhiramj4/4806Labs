package ThanosCorp.Lab4AbhiramSanthosh;

import org.springframework.data.jpa.repository.JpaRepository;

interface AddressBookRepository extends JpaRepository<AddressBook, Long> {

}