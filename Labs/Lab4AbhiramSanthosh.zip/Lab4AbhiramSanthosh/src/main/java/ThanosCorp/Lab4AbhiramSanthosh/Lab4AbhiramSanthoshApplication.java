package ThanosCorp.Lab4AbhiramSanthosh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4AbhiramSanthoshApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab4AbhiramSanthoshApplication.class, args);
	}

}
