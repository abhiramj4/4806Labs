package lab3;

public class Main {
    public static void main(String[] args) {
        Launcher launcher = new Launcher();
        launcher.launch();
    }
}
