package lab2;

public class main {

    public static void main(String[] args){

        AddressbookTest test = new AddressbookTest();
        test.performJPA();

    }
}
